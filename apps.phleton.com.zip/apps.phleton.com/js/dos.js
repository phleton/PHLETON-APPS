/**DOS.js*/
function get(id){return document.getElementById(id)}
function create(id){return document.createElement(id)}
function add(oParent,oChild){return document.addElement(oChild);}

/**
parseFloat()
parseInt()

getElementById('id')
getElementsByClassName
getElementsByTagName
createElement
documentElement
document.getElementById("canvas").style.display = 'none';

//window.captureEvents(Event.MOUSEDOWN | Event.MOUSEUP);
//---CROSS
document.onmousedown = MouseDown;
document.onmouseup   = MouseUp;
document.onmousemove = MouseMove;

document.body.scrollLeft
document.body.scrollUp... see D:\XAMPP\phpMyAdmin\js\pmd\move.js

var isIE = document.all && !window.opera;
var isNN = !document.all && document.getElementById;
var isN4 = document.layers;

window.onscroll = General_scroll;
document.onselectstart
**/